//
//  cvCollectionViewCell.swift
//  app_beta_uno
//
//  Created by Alan Escamilla Mondragon on 12/3/18.
//  Copyright © 2018 Alan Escamilla Mondragon. All rights reserved.
//

import UIKit

class cvCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cvButton: UIButton!
    @IBOutlet weak var cvLabel: UILabel!
}
