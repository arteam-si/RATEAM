//
//  eymCollectionViewCell.swift
//  app_beta_uno
//
//  Created by Alan Escamilla Mondragon on 12/3/18.
//  Copyright © 2018 Alan Escamilla Mondragon. All rights reserved.
//

import UIKit

class eymCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var eymLabel: UILabel!
    @IBOutlet weak var eymButton: UIButton!
}
