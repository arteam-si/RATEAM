//
//  CvDetailTopicViewController.swift
//  app_beta_uno
//
//  Created by Alan Escamilla Mondragon on 12/6/18.
//  Copyright © 2018 Alan Escamilla Mondragon. All rights reserved.
//

import UIKit

class CvDetailTopicViewController: UIViewController {
    
    //Tomamos lo enviado por el button de ViewController
    var topic = UIButton();
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var label: UILabel!
    
    //Temas de Cálculo Vectorial
    let cvChapters: Array<String> = ["Gradiente","Divergencia","Rotacional"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        scrollView.bottomAnchor.constraint(equalTo: label.bottomAnchor).isActive = true
        print(topic.tag)
        switch topic.tag {
        case 0:
            title = cvChapters[topic.tag]
            label.text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur vel lobortis lectus, condimentum viverra eros. Donec lacinia nisl a ligula mollis tristique. "
            break
        case 1:
            title = cvChapters[topic.tag]
            label.text = "La divergencia mide el cambio en la densidad de un fluido moviéndose de acuerdo con un campo vectorial dado."
            break
        case 2:
            title = cvChapters[topic.tag]
            label.text = "El rotacional es un operador que mide la rotación en el movimiento de un fluido descrito por un campo vectorial de tres dimensiones."
            break
        default: break
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
