//
//  SceneViewController.swift
//  app_beta_uno
//
//  Created by Alan Escamilla Mondragon on 12/10/18.
//  Copyright © 2018 Alan Escamilla Mondragon. All rights reserved.
//

import ARKit
class SceneViewController: UIViewController,ARSCNViewDelegate {
    
    let arView: ARSCNView = {
        let view = ARSCNView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arView.delegate = self
        view.addSubview(arView)
        arView.topAnchor.constraint(equalTo: view.topAnchor).isActive =  true
        arView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        arView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        arView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive =  true
        

        let configuration = ARWorldTrackingConfiguration()
        guard let refObjects = ARReferenceObject.referenceObjects(inGroupNamed:"gallery",bundle: Bundle.main) else {
            fatalError("Missing expected asset catalog resources.")
        }
        configuration.detectionObjects = refObjects
        
        arView.session.run(configuration, options: [.resetTracking,.removeExistingAnchors])
        
        
    }
    
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        
        let node = SCNNode()
        
        if let objectAnchor = anchor as? ARObjectAnchor {
            let visualitation = GaussLawOne(visName: "misile", objectAnchor: objectAnchor)

            node.addChildNode(visualitation.visNode)
            node.addChildNode(visualitation.planeNode)
            
            
        }
        return node
    }
}
