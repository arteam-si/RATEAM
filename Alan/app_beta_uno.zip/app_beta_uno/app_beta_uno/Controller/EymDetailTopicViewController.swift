//
//  EymDetailTopicViewController.swift
//  app_beta_uno
//
//  Created by Alan Escamilla Mondragon on 12/6/18.
//  Copyright © 2018 Alan Escamilla Mondragon. All rights reserved.
//

import UIKit

class EymDetailTopicViewController: UIViewController {
    
    //Tomamos lo enviado por el button de ViewController
    var topic = UIButton();
    
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var label: UILabel!
    
    //Temas de Electricidad y Magnetismo
    let maxwellLaws: Array<String> = ["Ley de Gauss","Ley de Ampere","Ley de Gauss para el Magnetismo","Ley de Inducción de Faraday"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //descriptionLabel.text = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
        // Do any additional setup after loading the view.
        scrollView.bottomAnchor.constraint(equalTo: label.bottomAnchor).isActive = true
        print(topic.tag)
        switch topic.tag {
        case 0:
            title = maxwellLaws[topic.tag]
            label.text = "La ley de Gauss es una de las 4 principales leyes del electromagnetismo. Su enunciado dice que \"el flujo eléctrico neto a través de cualquier superficie cerrada hipotética es proporcional a la carga neta encerrada por dicha superficie\""
            break
        case 1:
            title = maxwellLaws[topic.tag]
            label.text = "La integral de línea del campo magnético a lo largo de una trayectoria cerrada es proporcional a la corriente encerrada por la trayectoria"
            break
        case 2:
            title = maxwellLaws[topic.tag]
            label.text = "El flujo neto del campo magnético a trvés del de cualquier superficie cerrada es igual a cero debido a que no existe el monopolo magnético"
            break
        case 3:
            title = maxwellLaws[topic.tag]
            label.text = "La fuerza electromotriz en un circuito es igual al negativo de la velocidad con que cambia con el tiempo el flujo magnético a través del circuito"
            break
        default: break
        }
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension EymDetailTopicViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "eymDetailCell")
        cell.textLabel?.text = "Esto funciona"
        cell.textLabel?.textAlignment = .center
        cell.imageView?.image = UIImage(named: "gauss")
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        performSegue(withIdentifier: "arEymTransition", sender: indexPath.row)
    }
    
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let svc =  segue.destination as! SecondViewController
        svc.option = sender as! String
        
    }*/
    
    
    
}

