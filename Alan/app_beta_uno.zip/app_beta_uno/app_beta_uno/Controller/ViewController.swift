//
//  ViewController.swift
//  app_beta_uno
//
//  Created by Alan Escamilla Mondragon on 12/3/18.
//  Copyright © 2018 Alan Escamilla Mondragon. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Temas de Electricidad y Magnetismo
    let maxwellLaws: Array<String> = ["Ley de Gauss","Ley de Ampere","Ley de Gauss para el Magnetismo","Ley de Inducción de Faraday"]
    //Imagenes de Electricidad y Magnetismo
    let maxwellLawsImages: Array<String> = ["gauss","ar2","ar3","ar4"]
    //Temas de Cálculo Vectorial
    let cvChapters: Array<String> = ["Gradiente","Divergencia","Rotacional"]
    //Imagenes de Cálculo Vectorial
    let cvChaptersImages: Array<String> = ["ar1","ar2","ar3"]
    
    //Collection View de los temas principales de electricidad y mágnetismo
    @IBOutlet weak var eymCollectionView: UICollectionView!
    //Collection view de los temas principales de cálculo vectorial
    @IBOutlet weak var cvCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}
//Con esta extension de clase se busca separar las acciones que se haran dentro de los collections views
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    //Esta función nos cuantos elementos seran utilizados en el collection view
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == eymCollectionView {
            //Eletricidad y Magnetismo
            return maxwellLaws.count
        }else{
            //Cálculo Vectorial
            return cvChapters.count
        }
    }
    
    //Esta funcion nos permite editar cada unos de los elementos que estaran en las celdas de los collection views
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == eymCollectionView {
            let cell = eymCollectionView.dequeueReusableCell(withReuseIdentifier: "eym", for: indexPath) as! eymCollectionViewCell
            cell.eymButton.setImage(UIImage(named: maxwellLawsImages[indexPath.item]), for: .normal)
            cell.eymButton.layer.cornerRadius = 10
            cell.eymLabel.text = maxwellLaws[indexPath.item]
            cell.eymButton.tag = indexPath.item
            return cell
        }else{
            let cell = cvCollectionView.dequeueReusableCell(withReuseIdentifier: "cv", for: indexPath) as! cvCollectionViewCell
            cell.cvButton.setImage(UIImage(named: maxwellLawsImages[indexPath.item]), for: .normal)
            cell.cvButton.layer.cornerRadius = 10
            cell.cvLabel.text = cvChapters[indexPath.item]
            cell.cvButton.tag = indexPath.item
            return cell
        }
    }
    
    //Esta función nos dice que un elemento ha sido seleccionado para ir a una ruta especifica
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == eymCollectionView {
            eymCollectionView.deselectItem(at: indexPath, animated: true)
            performSegue(withIdentifier: "eymDetailTopicTransition", sender: maxwellLaws[indexPath.item])
        }else if collectionView == cvCollectionView{
            cvCollectionView.deselectItem(at: indexPath, animated: true)
            performSegue(withIdentifier: "cvDetailTopicTransition", sender: cvChapters[indexPath.item])
        }
    }
    

    
    //Notifica al controlador de vista que un segmento está a punto de realizarse.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "eymDetailTopicTransition"{
            let topic = segue.destination as! EymDetailTopicViewController
            topic.topic = sender as! UIButton
        }
        else if segue.identifier == "cvDetailTopicTransition"{
            let topic = segue.destination as! CvDetailTopicViewController
            topic.topic = sender as! UIButton
            print(topic.topic.tag)
        }
    }
    
    
    
    
}

