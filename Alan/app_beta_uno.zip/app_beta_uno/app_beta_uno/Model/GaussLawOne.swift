//
//  GaussLawOne.swift
//  app_beta_uno
//
//  Created by Alan Escamilla Mondragon on 1/28/19.
//  Copyright © 2019 Alan Escamilla Mondragon. All rights reserved.
//

import ARKit

class GaussLawOne{
    
    var plane = SCNPlane()
    var planeNode = SCNNode()
    var visScene = SCNScene()
    var visNode = SCNNode()
    
    
    init(visName: String,objectAnchor: ARObjectAnchor){
        self.plane = SCNPlane(width: CGFloat(objectAnchor.referenceObject.extent.x * 0.8), height: CGFloat(objectAnchor.referenceObject.extent.y * 0.5))
        plane.cornerRadius = plane.width * 0.125
        
        let displayScene = SKScene(fileNamed: "product")
        
        plane.firstMaterial?.diffuse.contents = displayScene
        plane.firstMaterial?.isDoubleSided = true
        plane.firstMaterial?.diffuse.contentsTransform = SCNMatrix4Translate(SCNMatrix4MakeScale(1, -1, 1), 0, 1, 0)
        
        planeNode = SCNNode(geometry: plane)
        planeNode.position = SCNVector3Make(objectAnchor.referenceObject.center.x, objectAnchor.referenceObject.center.y + 0.35, objectAnchor.referenceObject.center.z)
        
        
        let name = "art.scnassets/" + visName + ".scn"
        visScene = SCNScene(named: name)!
        visNode = visScene.rootNode.childNodes.first!
        visNode.position = SCNVector3Zero
        visNode.position.z = 0.05
        visNode.scale = SCNVector3(0.1, 0.1, 0.1)
    }
}
